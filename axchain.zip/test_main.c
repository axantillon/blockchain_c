#include "tests.h"

int main(void) {
    run_all_tests();
    return 0;
} 